8BitDo Ultimate C Wired Controller for Xbox (2dc8:2027), bcdDevice 1.14, USB cable.
Captured on Linux with usbmon (tcpdump -i usbmon0), driver xpad, kernel 7.2.11-100.fc43.x86_64 (Fedora 43).
The controller works here: light goes solid, input reports flow.

ultimate_c_xpad_linux.pcap  usbmon capture, link type USB_LINUX_MMAPPED. Only bus 3 is kept
                            (root hub, address 0 during enumeration, and the controller at address 5).
                            Starts before plug-in: port reset, enumeration, SET_CONFIGURATION,
                            SET_INTERFACE(1,0), the three xpad GIP packets, then about 40 s of input:
                            face buttons, bumpers, triggers, View, Menu, Guide, D-pad and both
                            sticks. No stick clicks appear in the data. Byte 18 of the input
                            report went to 1 once.
lsusb.txt                   lsusb -v and bound drivers (interface 0 -> xpad).

The serial number is replaced with X characters in the pcap and removed from lsusb.txt.
Open in Wireshark, filter: usb.bus_id == 3 && usb.device_address == 5
